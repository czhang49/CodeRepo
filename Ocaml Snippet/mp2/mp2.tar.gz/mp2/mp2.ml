(* CS 421 Fall 2015 MP2 *)

(* Problem 1 *)
let rec even_count l = raise(Failure "Function not implemented yet.")

(* Problem 2 *)
let rec split f lst = raise(Failure "Function not implemented yet.")

(* Problem 3 *)
let rec rle lst = raise(Failure "Function not implemented yet.")

(* Problem 4 *)
let rec sub_list l1 l2 =
    raise(Failure "Function not implemented yet.")

(* Problem 5 *)
let concat s list = raise(Failure "Function not implemented yet.")

(* Problem 6 *)
let split_base = ([2],[4]) (* Change this *)
let split_step f first (yes, no) =  raise(Failure "Function not implemented yet.")

(* Problem 7 *)
let rle2 lst =  raise(Failure "Function not implemented yet.")

(* Problem 8 *)
let concat2 s list =  raise(Failure "Function not implemented yet.")

(* Problem 9 *)
let app_all fs list =  raise(Failure "Function not implemented yet.")

(* Extra Credit, Problem 10 *)
let sub_list2 l1 l2 =  raise(Failure "Function not implemented yet.")
