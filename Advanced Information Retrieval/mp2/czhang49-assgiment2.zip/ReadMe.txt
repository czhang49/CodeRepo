To run codes, do:
1. source compile.sh 
2. source run.sh