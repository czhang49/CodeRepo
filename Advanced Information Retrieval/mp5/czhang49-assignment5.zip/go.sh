#!/bin/bash
source compile.sh;
source run.sh;
