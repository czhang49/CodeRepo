do the following:

source go.sh 

follow the instructions, the log likelihood and delta, along with the first 10 topic words in each topic will be displayed. 

It takes approximately 5 min to converge. 