#!/bin/bash

mkdir -p bin

javac -cp lib/weka.jar:bin -d bin -sourcepath src src/*.java

java -cp lib/weka.jar:bin cs446.homework2.FeatureGenerator ../data/badges.train ./../badges.train.arff
java -cp lib/weka.jar:bin cs446.homework2.FeatureGenerator ../data/badges.test.blind ./../badges.test.arff

java -cp lib/weka.jar:bin cs446.homework2.SGD ../badges.train.arff ../data/badges.test.blind ../badges.test.arff ../2.b.pred
java -cp lib/weka.jar:bin cs446.homework2.P2C ../badges.train.arff ../data/badges.test.blind ../badges.test.arff ../2.c.pred
java -cp lib/weka.jar:bin cs446.homework2.P2D4 ../badges.train.arff ../data/badges.test.blind ../badges.test.arff ../2.d.4.pred
java -cp lib/weka.jar:bin cs446.homework2.P2D8 ../badges.train.arff ../data/badges.test.blind ../badges.test.arff ../2.d.8.pred
java -cp lib/weka.jar:bin cs446.homework2.P2E ../badges.train.arff ../data/badges.test.blind ../badges.test.arff ../2.e.pred
