package cs446.homework2;

import java.io.*;
import java.util.*;

import weka.core.*;


public class Pred{
	List<String> name_list = new ArrayList<String>();
	Instances arff_features = null;
	List<Double> predictions = new ArrayList<Double>();


	public Pred(File name_file, File arff_file) throws Exception {
		//read the ARFF file
		arff_features = new Instances(new FileReader(arff_file));
		arff_features.setClassIndex(arff_features.numAttributes() -1 );
				
		//read the names
		BufferedReader br = new BufferedReader(new FileReader(name_file));
		String line;
		while ((line = br.readLine()) != null) {
			// process the line.
			String[] the_split_line = line.split(" ",2);
			name_list.add(the_split_line[1]);
		}
		br.close();

		if( name_list.size() != arff_features.numInstances())
			throw new Exception("The file and features don't seem to match!");

	}


	public void getPredictions(weka.classifiers.Classifier arg0) throws Exception {
		predictions.clear();


		for(int i = 0;i<arff_features.numInstances();i++){
			Instance inst = arff_features.instance(i);
			predictions.add(arg0.classifyInstance(inst));
		}
	}
	
	public List<String[]> getLabels(){
		Attribute the_class_attribute = arff_features.classAttribute();

		List<String[]> retval = new ArrayList<String[]>();

		for(int i = 0; i < name_list.size(); i++){
			String[] foo = new String[2];
			foo[0] = the_class_attribute.value(predictions.get(i).intValue());
			foo[1] = name_list.get(i);

			retval.add(foo);
		}

		return retval;
	}

	public void writePredictions(File output) throws Exception {
		PrintWriter writer = new PrintWriter(output);
		
		for(String[] foo : this.getLabels() ){
			writer.println(foo[0] + " " + foo[1]);
		}

		writer.close();
	}

	public static void main(String[] args) throws Exception {
		//test
		Pred mypred = new Pred(new File(args[0]), new File(args[1]) );

		
	}
}
