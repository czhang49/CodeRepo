package cs446.homework2;

import java.util.Arrays;
import java.io.*;

import weka.classifiers.*;
import weka.core.Instances;
import weka.core.Instance;

public abstract class ReportingModule {

	double[] accuracies;

	int NUM_FOLDS = 5;

	String train_arff;
	String test_names;
	String test_arff;
	String predictions_out;

	public ReportingModule(String[] args){
		accuracies = new double[NUM_FOLDS];

	       if (args.length != 4) {
         	   System.err.println("Usage: WekaTester arff-file test_names test_arff predictions_out");
       		     System.exit(-1);
       		 }

		train_arff = args[0];
		test_names = args[1];
		test_arff = args[2];
		predictions_out = args[3];

	}

	/**
	 * Should setup a classifer any other parameters needed.
	 */
	public abstract Classifier setUpClassifier();

	public void reporting() throws Exception {
        // Load the data
        Instances data = new Instances(new FileReader(new File(train_arff)));

        // The last attribute is the class label
        data.setClassIndex(data.numAttributes() - 1);

        for(int i = 0;i<NUM_FOLDS;i++){
                // Train on 80% of the data and test on 20%
                Instances train = data.trainCV(5, i);
                Instances test = data.testCV(5, i);

                //Use the overwritten setup method to create a classifier.
		Classifier classifier = setUpClassifier();

                // Train
                classifier.buildClassifier(train);

                // Evaluate on the test set
                Evaluation evaluation = new Evaluation(test);
                evaluation.evaluateModel(classifier, test);
                System.out.println(evaluation.toSummaryString());

		accuracies[i] = evaluation.pctCorrect();
        }

	//stuff about confidence intervals
	double mean = LinAlg.vect_norm(accuracies,1.0)/(double)(NUM_FOLDS);
	double std_dev = LinAlg.dot_product(accuracies, accuracies) / (double)NUM_FOLDS;
	std_dev -= Math.pow(mean,2.0);
	std_dev = Math.pow(std_dev, 0.5);

	double t = 4.604; // From the T-Table
	double lower_99 = mean - t*std_dev/Math.pow(NUM_FOLDS,0.5);
	double upper_99 = mean + t*std_dev/Math.pow(NUM_FOLDS,0.5);

	//Print output
	String acc_str = "[";
	for(int i = 0;i<NUM_FOLDS;i++){
		acc_str = acc_str + accuracies[i] + ",";
	}
	acc_str = acc_str.substring(0,acc_str.length() -1) + "]";
	System.out.println("ACCURACIES: " + acc_str);
	System.out.println("P_A: " + mean + "  STDDEV : " + std_dev + "99% confidence : [" + lower_99 + "," + upper_99 + "] " );

	//final prediction

	Classifier classifier = setUpClassifier();

        classifier.buildClassifier(data);

        Pred myPred = new Pred(new File(test_names), new File(test_arff) );
        myPred.getPredictions(classifier);
        myPred.writePredictions(new File(predictions_out));

    }

}
