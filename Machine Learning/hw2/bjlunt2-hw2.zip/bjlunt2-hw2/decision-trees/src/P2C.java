package cs446.homework2;

import java.io.File;
import java.io.FileReader;

import weka.classifiers.*;
import weka.core.Instances;
import cs446.weka.classifiers.trees.Id3;

public class P2C {

	static int MAX_DEPTH = -1;
	static int NUM_FOLDS = 5;

 public static void main(String[] args) throws Exception {

	    ReportingModule myReport = new ReportingModule(args){
		    public Classifier setUpClassifier(){
			    Id3 retval = new Id3();
			    retval.setMaxDepth(MAX_DEPTH);
			    return retval;
		    }
	    };

	    myReport.reporting();
    }

}
