package cs446.homework2;

import java.util.*;
import java.io.*;

import weka.classifiers.*;
import weka.core.Instances;
import weka.core.Instance;

public class SGD extends Classifier{

	private boolean trained = false;
	/*
	 * STUDENTS : What kind of state might you need to store in a classifier?
	 */
	double[] W_prime; //includes Theta
	double epsilon = 1.0e-10; //stopping threshold
	double eta_0 = 1.0e-3; //initial learning rate
	double eta = eta_0; // current learning rate
	double learning_decay = 1.0 - 1.0e-3;

       	int batch_size = 200;
	int max_epochs = 10000;


	static double[] instance_to_vector(Instance inst){
		double[] retval = new double[inst.numAttributes() + 1];
		double[] orig = inst.toDoubleArray();

		LinAlg.scalar_times_vector(2.0, orig);
		LinAlg.scalar_p_vector(-1.0, orig);		

		for(int i = 0;i<orig.length;i++)
			retval[i] = orig[i];

		double label = retval[retval.length -2];
		label = label > 0.0 ? 1.0 : -1.0 ;//We need the labels to be +-1 if they are to work

		retval[retval.length -1] = label; // move the label over
		retval[retval.length -2] = 1.0; // for Theta to multiply by

		return retval;
	}	

	@Override
	public void buildClassifier(Instances arg0) throws Exception {
		/*
		 * STUDENTS : Implement your learning algorithm (e.g. SGD) inside this function, at the end of this function, your classifier
		 * should be prepared to classify data.
		 */
		W_prime = new double[arg0.numAttributes() ];
		double[] W_old = new double[arg0.numAttributes() ];
		double[] Grad = new double[arg0.numAttributes() ];

		int N = arg0.numInstances();

		java.util.Random mySampler = new java.util.Random();

		double diff_last_epoch = 1000000.0;

		int num_epochs = 0;


		//It turns out that converting an instance to a vector each time is slow
		arg0.randomize(new java.util.Random(mySampler.nextLong()));

		//Do epochs of several batches.
		while(num_epochs < max_epochs && diff_last_epoch > epsilon){
			System.err.println("EPOCH : " + num_epochs);	
			//It may not be necessary to randomize after every cycle.
			//arg0.randomize(new java.util.Random(mySampler.nextLong()));
		
			//Do batches, needs better sampling.
			for(int j = 0;j< Math.max(1,N / batch_size); j++){	
				LinAlg.empty_vector(Grad);
				
				for(int i = 0;i<batch_size;i++){
					Instance one_instance = arg0.instance(j*batch_size + i);
					double[] x_i = instance_to_vector(one_instance);
					

					double class_value = x_i[x_i.length -1];
					x_i = Arrays.copyOfRange(x_i,0,x_i.length-1);
					double one_error = LinAlg.dot_product(W_prime,x_i) - class_value;
					LinAlg.vector_p_scalar_vector(Grad, one_error, x_i);
				}
				
				//Rolled into the line below
				//scalar_times_vector(1.0/batch_size, Grad);
				
				//W_new < W_prime + eta*Grad
				LinAlg.vector_p_scalar_vector(W_prime, -1.0 * eta / batch_size, Grad);
			}
			
			//Figure out the difference since the last epoch ||W_prime - W_old||_2
			LinAlg.vector_p_scalar_vector(W_old, -1.0, W_prime);
			diff_last_epoch = LinAlg.vect_norm(W_old,2.0);
			LinAlg.copy_vector(W_old, W_prime);
			
			//DEBUG
			//System.out.println("diff_last_epoch : " + diff_last_epoch); 
			//System.out.println("mean size " + LinAlg.vect_norm(W_prime,1.0)/(double)W_prime.length);

			eta = eta_0 * Math.pow(learning_decay, num_epochs);
			//eta = eta_0 * Math.pow(-1.0*learning_decay*(num_epochs+1), -2.0);
			//System.out.println("ETA : " + eta);
			num_epochs++;
		}
			//DEBUG
		//	print_vector(W_prime);
		
		System.out.println("Trained for " + num_epochs + " epochs");
		
		trained = true;//keep this
	}
	
	@Override
	public double classifyInstance(Instance instance) throws java.lang.Exception {
	/*	if(!trained){
			throw new Exception("The classifier is not trained!");
		}
	*/
		/*
		 * STUDENTS : Implement the decision function here.
		 *
		 * BEWARE: From the API, 
		 * 	Returns:
		 * 		index of the predicted class as a double if the class is nominal, otherwise the predicted value
		 *
		 * 		So for + -, if they are in that order in the ARFF file, you might return 0.0 and 1.0, respectively.
		 */
		
		double[] all_attributes = instance_to_vector(instance);
		all_attributes = Arrays.copyOfRange(all_attributes, 0, all_attributes.length-1);
		double lin = LinAlg.dot_product(W_prime, all_attributes);  
		
		return lin >= 0.0 ? 1.0 : 0.0 ; //Obviously change this!
	}

	public static void main(String[] args) throws Exception {

		ReportingModule myReport = new ReportingModule(args){
			public Classifier setUpClassifier(){
				return new SGD();
			}
		};
		
		myReport.reporting();
	}
}
