package cs446.homework2;

/**
 * I really don't want to write and re-write linear algebra inline.
 *
 * Not only will it make the code less readable, but that makes it less modifiable.
 * We want the code of our algorithm to read like its mathematical definition.
 *
 * So, all the linear algebra functions we use are stored here.
 *
 */
public class LinAlg {




	/**
	 * Take the dot product of a and b.
	 */
	static double dot_product(double[] a, double[] b) throws Exception {
		double retval = 0.0;

		if(a.length != b.length)
			throw new Exception("Vectors of unequal length");
		for(int i = 0;i<a.length;i++){
			retval += a[i]*b[i];
		}

		return retval;
	}

	/**
	 * Zero every element of a.
	 */
	static void empty_vector(double[] a){
		for(int i = 0;i < a.length;i++){
			a[i] = 0.0;
		}
	}

	/**
	 * Copy the contents of s to t .
	 */
	static void copy_vector(double[] t, double[] s) throws Exception {
		if(s.length != t.length)
			throw new Exception("Vectors of unequal length");

		for(int i = 0;i<s.length;i++){
			t[i] = s[i];
		}
	}

	/**
	 * a <- a + s*b
	 */
	static void vector_p_scalar_vector(double[] a, double s, double[] b) throws Exception {
		if(a.length != b.length)
			throw new Exception("Vectors of unequal length");

		double[] retval = new double[a.length];
		for(int i = 0;i<a.length;i++){
			a[i] += s*b[i];
		}
	}

	/**
	 * returns || a ||_n
	 */
	static double vect_norm(double[] a, double n){
		double total = 0.0;
		for(int i = 0; i<a.length;i++){
			total += Math.pow(a[i],n);
		}

		return Math.pow(total, 1.0/n);
	}

	/**
	 * a <- s*a
	 */
	static void scalar_times_vector(double s, double[] a){
		for(int i = 0;i<a.length;i++){
			a[i] = a[i]*s;
		}
	}

	/**
	 * a_i <- s + a_i
	 */
	static void scalar_p_vector(double s, double[] a){
		for(int i = 0;i<a.length;i++){
			a[i] = a[i] + s;
		}
	}

	/**
	 * print out the vector. (Useful for debugging.)
	 */
	static void print_vector(double[] a){
		System.out.println("[");
		for(int i = 0; i< a.length;i++){
			System.out.println(a[i]);
		}
		System.out.println("]");
	}

}
