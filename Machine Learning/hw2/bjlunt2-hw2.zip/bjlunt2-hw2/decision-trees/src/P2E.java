package cs446.homework2;

import java.io.File;
import java.io.FileReader;

import weka.classifiers.*;
import weka.core.Instances;
import cs446.weka.classifiers.trees.Id3;

public class P2E {

	static int MAX_DEPTH = 4;
	static int NUM_FOLDS = 5;
	static int NUM_TREES = 100;

	public static class SubSampledId3 extends Id3{

		public static java.util.Random myRand = new java.util.Random();

		@Override
		public void buildClassifier(Instances arg0) throws Exception {
			//Train on a random subset of half the data.
			arg0.randomize(new java.util.Random(myRand.nextLong()));
			
			Instances subsample;
		       	//subsample = arg0.resample(new java.util.Random(myRand.nextLong())).trainCV(2,0);
			subsample = arg0.trainCV(2,0);

			//Call the training method of the superclass.
			super.buildClassifier(subsample);
		}


	}


public static void main(String[] args) throws Exception {
	    ReportingModule myReport = new ReportingModule(args){
		    public Classifier setUpClassifier(){
			    SubSampledId3 base[] = new SubSampledId3[NUM_TREES];
			    for(int i = 0;i<NUM_TREES;i++){
				    base[i] = new SubSampledId3();
				    base[i].setMaxDepth(MAX_DEPTH);
			    }

			    weka.classifiers.meta.Stacking retval = new weka.classifiers.meta.Stacking();

			    retval.setClassifiers(base);

			    

			    SGD high_level = new SGD();
			    high_level.eta_0 = 1.0e-2;	

			high_level.batch_size = 100;
			high_level.max_epochs = 20000;

			    retval.setMetaClassifier(high_level);

			    return retval;
		    }
	    };

	    myReport.reporting();
    }

}
