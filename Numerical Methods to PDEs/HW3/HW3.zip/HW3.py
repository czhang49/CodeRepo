import mesh2d;
import matplotlib.pyplot as plt;
import febasic_template;



V,E=mesh2d.xml('simple.xml');
#plt.triplot(V[:,0],V[:,1],E)
#plt.show();

run febasic_template.py

